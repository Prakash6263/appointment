const Plan = require("../models/Plan")

// Create Plan
exports.createPlan = async (req, res) => {
  try {
    const { name, description, price, billingCycle, customerLimit, features } = req.body

    // Reject if providerLimit is in payload
    if (req.body.providerLimit !== undefined) {
      return res.status(400).json({
        success: false,
        message: "providerLimit is not supported",
      })
    }

    // Reject if analytics feature is in payload
    if (req.body.features && req.body.features.analytics !== undefined) {
      return res.status(400).json({
        success: false,
        message: "analytics feature is not supported",
      })
    }

    // Validate required fields
    if (!name || !billingCycle || customerLimit === undefined) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields: name, billingCycle, customerLimit",
      })
    }

    // Check if plan already exists
    const existingPlan = await Plan.findOne({ name })
    if (existingPlan) {
      return res.status(400).json({
        success: false,
        message: "Plan already exists",
      })
    }

    // Create new plan with only allowed features
    const allowedFeatures = {
      branding: features?.branding || false,
      domain: features?.domain || false,
    }

    const plan = new Plan({
      name,
      description: description || "",
      price: price || 0,
      billingCycle,
      customerLimit,
      features: allowedFeatures,
    })

    await plan.save()

    res.status(201).json({
      success: true,
      message: "Plan created successfully",
      data: plan,
    })
  } catch (error) {
    console.error("Create plan error:", error)
    res.status(500).json({
      success: false,
      message: error.message || "Failed to create plan",
    })
  }
}

// Update Plan
exports.updatePlan = async (req, res) => {
  try {
    const { id } = req.params
    const { name, description, price, billingCycle, customerLimit, features, isActive } = req.body

    // Reject if providerLimit is in payload
    if (req.body.providerLimit !== undefined) {
      return res.status(400).json({
        success: false,
        message: "providerLimit is not supported",
      })
    }

    // Reject if analytics feature is in payload
    if (req.body.features && req.body.features.analytics !== undefined) {
      return res.status(400).json({
        success: false,
        message: "analytics feature is not supported",
      })
    }

    // Find plan
    const plan = await Plan.findById(id)
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: "Plan not found",
      })
    }

    // Update allowed fields
    if (name) plan.name = name
    if (description !== undefined) plan.description = description
    if (price !== undefined) plan.price = price
    if (billingCycle) plan.billingCycle = billingCycle
    if (customerLimit !== undefined) plan.customerLimit = customerLimit
    if (features) {
      const allowedFeatures = {
        branding: features.branding !== undefined ? features.branding : plan.features.branding,
        domain: features.domain !== undefined ? features.domain : plan.features.domain,
      }
      plan.features = allowedFeatures
    }
    if (isActive !== undefined) plan.isActive = isActive

    await plan.save()

    res.json({
      success: true,
      message: "Plan updated successfully",
      data: plan,
    })
  } catch (error) {
    console.error("Update plan error:", error)
    res.status(500).json({
      success: false,
      message: error.message || "Failed to update plan",
    })
  }
}

// List Plans
exports.listPlans = async (req, res) => {
  try {
    const plans = await Plan.find({ isActive: true }).sort({ createdAt: -1 })

    res.json({
      success: true,
      message: "Plans retrieved successfully",
      data: plans,
    })
  } catch (error) {
    console.error("List plans error:", error)
    res.status(500).json({
      success: false,
      message: error.message || "Failed to list plans",
    })
  }
}

// Get Plan by ID
exports.getPlanById = async (req, res) => {
  try {
    const { id } = req.params

    const plan = await Plan.findById(id)
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: "Plan not found",
      })
    }

    res.json({
      success: true,
      message: "Plan retrieved successfully",
      data: plan,
    })
  } catch (error) {
    console.error("Get plan error:", error)
    res.status(500).json({
      success: false,
      message: error.message || "Failed to get plan",
    })
  }
}
